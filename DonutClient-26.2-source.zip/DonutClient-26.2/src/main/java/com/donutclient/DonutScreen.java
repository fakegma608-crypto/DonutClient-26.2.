package com.donutclient;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Lightweight toggle panel. Orange accents are drawn with vanilla GUI primitives. */
public final class DonutScreen extends Screen {
    public DonutScreen() { super(Component.literal("DONUT CLIENT")); }

    @Override
    protected void init() {
        int left = this.width / 2 - 105;
        int top = this.height / 2 - 85;
        int w = 210;
        int h = 20;
        addRenderableWidget(Button.builder(label("Diagnostics", DonutClient.diagnosticsEnabled), b -> {
            DonutClient.diagnosticsEnabled = !DonutClient.diagnosticsEnabled;
            DonutClient.addDiagnostic("Diagnostics toggled " + (DonutClient.diagnosticsEnabled ? "on" : "off"));
            b.setMessage(label("Diagnostics", DonutClient.diagnosticsEnabled));
        }).bounds(left, top, w, h).build());
        addRenderableWidget(Button.builder(label("Base Finder", DonutClient.baseFinderEnabled), b -> {
            DonutClient.baseFinderEnabled = !DonutClient.baseFinderEnabled;
            DonutClient.addDiagnostic("Base Finder toggled " + (DonutClient.baseFinderEnabled ? "on" : "off"));
            b.setMessage(label("Base Finder", DonutClient.baseFinderEnabled));
        }).bounds(left, top + 24, w, h).build());
        addRenderableWidget(Button.builder(label("Kelp filter", DonutClient.kelpFilter), b -> {
            DonutClient.kelpFilter = !DonutClient.kelpFilter; b.setMessage(label("Kelp filter", DonutClient.kelpFilter));
        }).bounds(left, top + 48, w, h).build());
        addRenderableWidget(Button.builder(label("Amethyst filter", DonutClient.amethystFilter), b -> {
            DonutClient.amethystFilter = !DonutClient.amethystFilter; b.setMessage(label("Amethyst filter", DonutClient.amethystFilter));
        }).bounds(left, top + 72, w, h).build());
        addRenderableWidget(Button.builder(label("Deepslate filter", DonutClient.deepslateFilter), b -> {
            DonutClient.deepslateFilter = !DonutClient.deepslateFilter; b.setMessage(label("Deepslate filter", DonutClient.deepslateFilter));
        }).bounds(left, top + 96, w, h).build());
        addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
                .bounds(left, top + 126, w, h).build());
    }

    private static Component label(String name, boolean enabled) {
        return Component.literal(name + ": " + (enabled ? "ON" : "OFF"));
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        renderBackground(graphics, mouseX, mouseY, delta);
        int left = this.width / 2 - 120;
        int top = this.height / 2 - 105;
        graphics.fill(left, top, left + 240, top + 180, 0xEE151515);
        graphics.fill(left, top, left + 240, top + 3, 0xFFFF6A00);
        graphics.drawString(font, "DONUT CLIENT", left + 12, top + 10, 0xFFFF6A00, true);
        graphics.drawString(font, "Private-server diagnostics", left + 12, top + 22, 0xFFBBBBBB, true);
        graphics.drawString(font, DonutClient.lastDiagnostic, left + 12, top + 164, 0xFFE5E5E5, true);
        super.render(graphics, mouseX, mouseY, delta);
    }

    @Override public boolean isPauseScreen() { return false; }
}
