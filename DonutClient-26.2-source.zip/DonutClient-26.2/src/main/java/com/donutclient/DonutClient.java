package com.donutclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import org.lwjgl.glfw.GLFW;

/**
 * Donut Client bootstrap. This source targets Minecraft 26.2 named APIs.
 * The build must be verified against the exact Fabric API artifacts before release.
 */
public final class DonutClient implements ClientModInitializer {
    public static boolean guiEnabled = false;
    public static boolean diagnosticsEnabled = true;
    public static boolean baseFinderEnabled = false;
    public static boolean kelpFilter = true;
    public static boolean amethystFilter = true;
    public static boolean deepslateFilter = false;
    public static boolean fpsHud = true;
    public static boolean coordinatesHud = true;
    public static boolean moduleListHud = true;
    public static boolean keystrokesHud = false;
    public static int searchRadius = 24;
    public static String lastDiagnostic = "No suspicious events recorded";

    private static KeyMapping openGuiKey;

    @Override
    public void onInitializeClient() {
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.donutclient.open_gui",
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyMapping.Category.MISC
        ));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.consumeClick()) {
                if (client.screen == null) client.setScreen(new DonutScreen());
                else if (client.screen instanceof DonutScreen) client.setScreen(null);
            }
        });
        HudRenderCallback.EVENT.register((graphics, tickCounter) -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.options.hideGui) return;
            int y = 8;
            graphics.drawString(mc.font, "DONUT CLIENT", 8, y, 0xFFFF6A00, true);
            y += 12;
            if (fpsHud) {
                graphics.drawString(mc.font, "FPS: " + mc.getFps(), 8, y, 0xFFFFB347, true);
                y += 11;
            }
            if (coordinatesHud) {
                graphics.drawString(mc.font, String.format("XYZ: %.1f / %.1f / %.1f",
                        mc.player.getX(), mc.player.getY(), mc.player.getZ()), 8, y, 0xFFE5E5E5, true);
                y += 11;
            }
            if (moduleListHud) {
                if (diagnosticsEnabled) graphics.drawString(mc.font, "Diagnostics: ON", 8, y, 0xFFFF6A00, true);
                y += 11;
                if (baseFinderEnabled) graphics.drawString(mc.font, "Base Finder: ON (loaded chunks only)", 8, y, 0xFFFF6A00, true);
            }
        });
    }

    public static void addDiagnostic(String message) {
        lastDiagnostic = message;
    }
}
