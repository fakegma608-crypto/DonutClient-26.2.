# Donut Client — Minecraft Java 26.2 (Fabric)

## Important build status
This is a **source project, not a verified release**. It has not been compiled in this environment: the available runtime is Java 21, while Minecraft 26.2 requires Java 25, and outbound package downloads are unavailable. Do not rename source files to `.jar`; that does not create a mod. A real release JAR must be built and tested with the exact Fabric/Loom artifacts.

## Target toolchain
- Minecraft Java Edition 26.2
- Java 25
- Fabric Loader 0.19.3
- Fabric Loom 1.17.x
- Gradle 9.5.1
- Fabric API 0.152.0+26.2 (verify artifact availability)

## Build
1. Install a Java 25 JDK and Gradle 9.5.1.
2. From this project directory, run `gradle build`.
3. If dependency resolution succeeds, inspect `build/libs/DonutClient-26.2-1.0.0.jar` and verify `fabric.mod.json` and compiled classes are present.
4. Install Fabric Loader for Minecraft 26.2, then copy the built JAR into `.minecraft/mods`.

## Current implementation scope
- Right Shift keybind opens/closes a compact GUI.
- HUD displays FPS and coordinates with toggles for diagnostics and module labels.
- GUI toggles diagnostics and the individual block filter flags.
- The diagnostic panel records the last locally generated toggle message.

## Not yet implemented / verified
This source does **not yet implement** block scanning/highlighting, per-block distance HUD, configuration persistence, movement-correction/packet diagnostics, a draggable window, HUD editor, or keystrokes. Those features require additional Minecraft 26.2 API work and runtime testing. The Base Finder toggles are UI state only at this stage. Do not use this project as if it were the complete client requested.

## Safety and limitations
Client-side block inspection can only inspect chunks already loaded by the game; it cannot reveal unloaded or server-hidden blocks. Client-side diagnostics are not server anticheat and do not bypass or conceal modifications.
